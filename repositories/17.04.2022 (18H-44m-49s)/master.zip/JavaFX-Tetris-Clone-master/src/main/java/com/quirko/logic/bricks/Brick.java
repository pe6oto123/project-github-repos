package com.quirko.logic.bricks;

import java.util.List;

public interface Brick {

    List<int[][]> getShapeMatrix();
}
