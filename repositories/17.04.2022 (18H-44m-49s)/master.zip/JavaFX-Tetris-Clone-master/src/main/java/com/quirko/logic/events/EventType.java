package com.quirko.logic.events;

public enum EventType {
    DOWN, LEFT, RIGHT, ROTATE
}
